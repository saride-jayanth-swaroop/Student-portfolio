document.getElementById('openModal').addEventListener('click', function() {
    document.getElementById('contactModal').style.display = 'block';
});

document.getElementsByClassName('close')[0].addEventListener('click', function() {
    document.getElementById('contactModal').style.display = 'none';
});

window.addEventListener('click', function(event) {
    if (event.target == document.getElementById('contactModal')) {
        document.getElementById('contactModal').style.display = 'none';
    }
});

document.getElementById('contact-form').addEventListener('submit', function(event) {
    event.preventDefault();
    
    const name = document.getElementById('name').value;
    const email = document.getElementById('email').value;

    // Name validation: Must have fewer than 10 characters
    if (name.length >= 10) {
        alert('Name must contain fewer than 10 characters.');
        return;
    }

    // Email validation: Must contain the "@" symbol
    if (!email.includes('@')) {
        alert('Please enter a valid email address containing "@" symbol.');
        return;
    }
    
    alert(`Thank you, ${name}! Your message has been received.`);
    
    // Clear the form fields
    document.getElementById('contact-form').reset();

    // Close the modal
    document.getElementById('contactModal').style.display = 'none';
});
